TRENDORA STORE — Professional E-Commerce Template v2.0
======================================================
FILES: index.html, products.html, product.html, offers.html, contact.html, checkout.html, style.css, store.js, README.txt

FEATURES ADDED:
✅ Dynamic cart with LocalStorage persistence
✅ Real-time search, filtering & sorting
✅ Countdown timer for offers + promo code copy
✅ Smart checkout with validation & promo logic
✅ Fully responsive mobile-first design
✅ SEO & Accessibility ready (focus states, semantic tags)

HOW TO RUN:
1. Put all files in ONE folder.
2. Open index.html in any browser.
3. Test cart, filters, checkout flow.

DEPLOY TO GITHUB PAGES:
1. Create repo → Upload all files → Commit.
2. Settings → Pages → Source: Deploy from branch → main / (root) → Save.
3. Visit https://YOURUSERNAME.github.io/YOURREPO/

CUSTOMIZE:
- Colors: Edit :root variables in style.css
- Products: Edit PRODUCTS array in store.js
- Add Images: Create /images folder, set image: 'images/file.jpg' in store.js
- Currency: Search & replace "$" with "€" or "£" globally.

Support: info@trendora.com | © 2026 Trendora